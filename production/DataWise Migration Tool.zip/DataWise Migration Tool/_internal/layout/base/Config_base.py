def config_window(self):
        self.title("DataWise Migrator Tool")
        self.geometry(f"{640}x{480}")
        # self.minsize()